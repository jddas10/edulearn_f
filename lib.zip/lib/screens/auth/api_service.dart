import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';

const String kBaseUrl = 'https://stroke-armed-surprise-diverse.trycloudflare.com';
const Duration kTimeout = Duration(seconds: 20);

class SessionStore {
  static const _token  = 'token';
  static const _role   = 'user_role';
  static const _name   = 'name';
  static const _userId = 'user_id';
  static const _deviceId = 'deviceId';

  static Future<void> save({
    required String token,
    required String role,
    required String name,
    required int userId,
  }) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_token, token);
    await p.setString(_role, role);
    await p.setString(_name, name);
    await p.setInt(_userId, userId);
  }

  static Future<String?> get token  async => (await SharedPreferences.getInstance()).getString(_token);
  static Future<String?> get role   async => (await SharedPreferences.getInstance()).getString(_role);
  static Future<String?> get name   async => (await SharedPreferences.getInstance()).getString(_name);
  static Future<int?>    get userId async => (await SharedPreferences.getInstance()).getInt(_userId);
  static Future<String?> get deviceId async => (await SharedPreferences.getInstance()).getString(_deviceId);
  static Future<bool>    get isLoggedIn async => (await token) != null;
  static Future<void>    clear() async => (await SharedPreferences.getInstance()).clear();
}

class _Http {
  static Future<Map<String, String>> get _headers async {
    final t = await SessionStore.token;
    return {
      'Content-Type': 'application/json',
      if (t != null) 'Authorization': 'Bearer $t',
    };
  }

  static Map<String, dynamic> _parse(http.Response res) {
    try {
      return jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {
      return {'success': false, 'message': 'Invalid server response (${res.statusCode})'};
    }
  }

  static Map<String, dynamic> _error(Object e) {
    if (e is SocketException) {
      return {'success': false, 'message': 'Connection error. Check internet.'};
    }
    return {'success': false, 'message': 'Request failed: $e'};
  }

  static Future<Map<String, dynamic>> get(String path, {Map<String, String>? query}) async {
    try {
      final uri = Uri.parse('$kBaseUrl$path').replace(queryParameters: query);
      final res = await http.get(uri, headers: await _headers).timeout(kTimeout);
      return _parse(res);
    } catch (e) {
      return _error(e);
    }
  }

  static Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    try {
      final res = await http
          .post(Uri.parse('$kBaseUrl$path'), headers: await _headers, body: jsonEncode(body))
          .timeout(kTimeout);
      return _parse(res);
    } catch (e) {
      return _error(e);
    }
  }

  static Future<Map<String, dynamic>> put(String path, Map<String, dynamic> body) async {
    try {
      final res = await http
          .put(Uri.parse('$kBaseUrl$path'), headers: await _headers, body: jsonEncode(body))
          .timeout(kTimeout);
      return _parse(res);
    } catch (e) {
      return _error(e);
    }
  }

  static Future<Map<String, dynamic>> delete(String path) async {
    try {
      final res = await http
          .delete(Uri.parse('$kBaseUrl$path'), headers: await _headers)
          .timeout(kTimeout);
      return _parse(res);
    } catch (e) {
      return _error(e);
    }
  }
}

Dio _dio() => Dio(BaseOptions(
  baseUrl: kBaseUrl,
  connectTimeout: kTimeout,
  receiveTimeout: const Duration(seconds: 120),
));

Future<Options> _dioOpts() async {
  final t = await SessionStore.token;
  return Options(headers: {if (t != null) 'Authorization': 'Bearer $t'});
}

class AuthApi {
  static Future<Map<String, dynamic>> login({
    required String username,
    required String password,
    required String role,
  }) async {
    final res = await _Http.post('/auth/login', {
      'username': username.trim(),
      'password': password,
      'role': role.toUpperCase(),
    });
    if (res['success'] == true) {
      await SessionStore.save(
        token: res['token'],
        role: res['role'],
        name: res['name'],
        userId: res['userId'],
      );
    }
    return res;
  }
  static Future<void> logout() => SessionStore.clear();
}

class AttendanceApi {
  static Future<Map<String, dynamic>> startSession({
    required String title,
    required double lat,
    required double lng,
    int radiusM = 100,
    int accuracyM = 50,
    int durationMinutes = 10,
    int nonceTtlSeconds = 20,
  }) =>
      _Http.post('/attendance/start', {
        'title': title, 'lat': lat, 'lng': lng,
        'radiusM': radiusM, 'accuracyM': accuracyM,
        'durationMinutes': durationMinutes, 'nonceTtlSeconds': nonceTtlSeconds,
      });

  static Future<Map<String, dynamic>> refreshNonce({required String sessionId, int ttlSeconds = 20}) =>
      _Http.post('/attendance/nonce', {'sessionId': sessionId, 'ttlSeconds': ttlSeconds});

  static Future<Map<String, dynamic>> closeSession(String sessionId) =>
      _Http.post('/attendance/close', {'sessionId': sessionId});

  static Future<Map<String, dynamic>> getSessions({String? date}) =>
      _Http.get('/attendance/sessions', query: date != null ? {'date': date} : null);

  static Future<Map<String, dynamic>> markAttendance({
    required String sessionId,
    required String nonce,
    required double lat,
    required double lng,
    required int accuracyM,
    required String deviceId,
  }) =>
      _Http.post('/attendance/mark', {
        'sessionId': sessionId, 'nonce': nonce,
        'lat': lat, 'lng': lng, 'accuracyM': accuracyM, 'deviceId': deviceId,
      });
}

class LectureApi {
  static Future<Map<String, dynamic>> uploadLecture({
    required String videoFilePath,
    required String title,
    String subject = '',
    String category = '',
    void Function(int sent, int total)? onProgress,
  }) async {
    try {
      final formData = FormData.fromMap({
        'title': title, 'subject': subject, 'category': category,
        'video': await MultipartFile.fromFile(videoFilePath, filename: videoFilePath.split('/').last),
      });
      final res = await _dio().post('/lectures/upload', data: formData, options: await _dioOpts(), onSendProgress: onProgress);
      return res.data;
    } on DioException catch (e) {
      return {'success': false, 'message': e.response?.data?['message'] ?? 'Upload failed'};
    } catch (e) {
      return {'success': false, 'message': 'Error: $e'};
    }
  }
  static Future<Map<String, dynamic>> deleteLecture(int id) => _Http.delete('/lectures/$id');
  static Future<Map<String, dynamic>> getLectures() => _Http.get('/lectures');
}

class QuizApi {
  static Future<Map<String, dynamic>> getTeacherQuizzes() => _Http.get('/api/quiz/teacher');
  static Future<Map<String, dynamic>> createQuiz({required String title, required int totalMarks, required List<Map<String, dynamic>> questions}) =>
      _Http.post('/api/quiz/create', {'title': title, 'totalMarks': totalMarks, 'questions': questions});
  static Future<Map<String, dynamic>> deleteQuiz(int id) => _Http.delete('/api/quiz/$id');
  static Future<Map<String, dynamic>> getResults(int id) => _Http.get('/api/quiz/$id/results');
  static Future<Map<String, dynamic>> getStudentQuizzes() => _Http.get('/api/quiz/student');
  static Future<Map<String, dynamic>> submitQuiz({required int quizId, required Map<String, String> answers}) =>
      _Http.post('/api/quiz/$quizId/submit', {'answers': answers});
}

class ClassApi {
  static Future<Map<String, dynamic>> getClasses() => _Http.get('/classes');
  static Future<Map<String, dynamic>> createClass({required String name, required String subject, required List<int> studentIds}) =>
      _Http.post('/classes/create', {'name': name, 'subject': subject, 'studentIds': studentIds});
}

class MarksApi {
  static Future<Map<String, dynamic>> getMyMarks() => _Http.get('/marks/student');
}