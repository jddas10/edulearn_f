import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TeacherRecordedScreen extends StatefulWidget {
  const TeacherRecordedScreen({super.key});

  @override
  State<TeacherRecordedScreen> createState() => _TeacherRecordedScreenState();
}

class _TeacherRecordedScreenState extends State<TeacherRecordedScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _bgCtl;
  final TextEditingController _searchCtl = TextEditingController();

  bool _showSearch = false;
  String _searchQuery = '';

  final List<_LectureItem> _lectures = [
    _LectureItem(
      title: 'Operating Systems - Intro',
      subject: 'Operating Systems',
      category: 'Lecture',
      uploadedAt: DateTime(2026, 2, 18, 12, 29),
      duration: '45:12',
    ),
    _LectureItem(
      title: 'Process Scheduling',
      subject: 'Operating Systems',
      category: 'Lecture',
      uploadedAt: DateTime(2026, 2, 17, 10, 0),
      duration: '38:55',
    ),
    _LectureItem(
      title: 'Data Structures - Trees',
      subject: 'DSA',
      category: 'Tutorial',
      uploadedAt: DateTime(2026, 2, 15, 14, 30),
      duration: '52:08',
    ),
  ];

  List<_LectureItem> get _filtered => _lectures
      .where((l) =>
  l.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
      l.subject.toLowerCase().contains(_searchQuery.toLowerCase()))
      .toList();

  @override
  void initState() {
    super.initState();
    _bgCtl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _bgCtl.dispose();
    _searchCtl.dispose();
    super.dispose();
  }

  void _showUploadDialog() {
    final titleCtl = TextEditingController();
    final subjectCtl = TextEditingController();
    final categoryCtl = TextEditingController();
    const accent = Color(0xFF00E5FF);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0D1B2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.upload_rounded, color: accent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Upload Lecture',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              _DialogField(controller: titleCtl, hint: 'Title', icon: Icons.title_rounded),
              const SizedBox(height: 14),
              _DialogField(controller: subjectCtl, hint: 'Subject', icon: Icons.book_rounded),
              const SizedBox(height: 14),
              _DialogField(controller: categoryCtl, hint: 'Category', icon: Icons.label_rounded),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.video_file_rounded, color: Colors.white38, size: 18),
                    const SizedBox(width: 10),
                    Text(
                      'No video selected',
                      style: TextStyle(color: Colors.white38, fontSize: 13),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: accent.withOpacity(0.3)),
                        ),
                        child: Text(
                          'Browse',
                          style: TextStyle(color: accent, fontSize: 12, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel',
                        style: TextStyle(color: Colors.white38, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      if (titleCtl.text.trim().isEmpty) return;
                      setState(() {
                        _lectures.insert(
                          0,
                          _LectureItem(
                            title: titleCtl.text.trim(),
                            subject: subjectCtl.text.trim().isEmpty
                                ? 'General'
                                : subjectCtl.text.trim(),
                            category: categoryCtl.text.trim().isEmpty
                                ? 'Lecture'
                                : categoryCtl.text.trim(),
                            uploadedAt: DateTime.now(),
                            duration: '--:--',
                          ),
                        );
                      });
                      Navigator.pop(context);
                      HapticFeedback.mediumImpact();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('Lecture uploaded successfully!'),
                          backgroundColor: const Color(0xFF00838F),
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                        color: accent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text(
                        'Upload',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _deleteItem(int index) {
    setState(() => _lectures.removeAt(index));
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00E5FF);
    const bg = Color(0xFF030810);

    return Scaffold(
      backgroundColor: bg,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _bgCtl,
            builder: (context, _) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _RecordedBgPainter(progress: _bgCtl.value),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 12, 8, 4),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back_ios_new_rounded,
                            color: Colors.white70, size: 20),
                      ),
                      const SizedBox(width: 2),
                      Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          color: const Color(0xFFB84A00).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: const Color(0xFFB84A00).withOpacity(0.4), width: 1),
                        ),
                        child: const Icon(Icons.video_library_rounded,
                            color: Color(0xFFFF7043), size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Recorded Lectures',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Manage your video lectures',
                            style: TextStyle(fontSize: 12, color: Colors.white38),
                          ),
                        ],
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            _showSearch = !_showSearch;
                            if (!_showSearch) {
                              _searchQuery = '';
                              _searchCtl.clear();
                            }
                          });
                        },
                        icon: Icon(
                          _showSearch ? Icons.close_rounded : Icons.search_rounded,
                          color: Colors.white70,
                          size: 22,
                        ),
                      ),
                      IconButton(
                        onPressed: _showUploadDialog,
                        icon: const Icon(Icons.upload_rounded, color: Color(0xFF00E5FF), size: 22),
                      ),
                    ],
                  ),
                ),
                AnimatedSize(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  child: _showSearch
                      ? Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                    child: TextField(
                      controller: _searchCtl,
                      autofocus: true,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      cursorColor: accent,
                      onChanged: (v) => setState(() => _searchQuery = v),
                      decoration: InputDecoration(
                        hintText: 'Search lectures...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                        prefixIcon: const Icon(Icons.search_rounded,
                            color: Colors.white38, size: 20),
                        filled: true,
                        fillColor: const Color(0xFF0A1628),
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide:
                          BorderSide(color: accent.withOpacity(0.4), width: 1),
                        ),
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),
                ),
                Expanded(
                  child: _filtered.isEmpty
                      ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.video_library_outlined,
                            size: 64, color: Colors.white12),
                        const SizedBox(height: 12),
                        Text(
                          _searchQuery.isNotEmpty
                              ? 'No lectures found'
                              : 'No lectures uploaded yet',
                          style: const TextStyle(
                              color: Colors.white38, fontSize: 15),
                        ),
                        if (_searchQuery.isEmpty) ...[
                          const SizedBox(height: 16),
                          GestureDetector(
                            onTap: _showUploadDialog,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              decoration: BoxDecoration(
                                color: accent.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: accent.withOpacity(0.3)),
                              ),
                              child: Text('Upload First Lecture',
                                  style: TextStyle(
                                      color: accent, fontWeight: FontWeight.w600)),
                            ),
                          ),
                        ],
                      ],
                    ),
                  )
                      : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                    itemCount: _filtered.length,
                    itemBuilder: (context, i) {
                      final item = _filtered[i];
                      final realIndex = _lectures.indexOf(item);
                      return _LectureCard(
                        item: item,
                        onDelete: () => _deleteItem(realIndex),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DialogField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  const _DialogField({
    required this.controller,
    required this.hint,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00E5FF);
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white, fontSize: 14),
      cursorColor: accent,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true,
        fillColor: Colors.white.withOpacity(0.05),
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accent.withOpacity(0.5), width: 1.5),
        ),
      ),
    );
  }
}

class _LectureCard extends StatelessWidget {
  final _LectureItem item;
  final VoidCallback onDelete;
  const _LectureCard({required this.item, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00E5FF);
    final dateStr =
        '${item.uploadedAt.day}/${item.uploadedAt.month}/${item.uploadedAt.year}  ${item.uploadedAt.hour.toString().padLeft(2, '0')}:${item.uploadedAt.minute.toString().padLeft(2, '0')}';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1628),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.07)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFFB84A00).withOpacity(0.18),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: const Color(0xFFB84A00).withOpacity(0.3), width: 1),
                ),
                child: const Icon(Icons.play_arrow_rounded,
                    color: Color(0xFFFF7043), size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _MiniChip(label: item.subject, color: accent),
                        const SizedBox(width: 6),
                        _MiniChip(label: item.category, color: Colors.white38),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.access_time_rounded,
                            size: 11, color: Colors.white30),
                        const SizedBox(width: 4),
                        Text(dateStr,
                            style: const TextStyle(
                                color: Colors.white30, fontSize: 11)),
                        if (item.duration != '--:--') ...[
                          const SizedBox(width: 10),
                          Icon(Icons.timer_rounded, size: 11, color: Colors.white30),
                          const SizedBox(width: 4),
                          Text(item.duration,
                              style: const TextStyle(
                                  color: Colors.white30, fontSize: 11)),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                children: [
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.bookmark_border_rounded,
                        color: Colors.white38, size: 20),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  const SizedBox(height: 8),
                  IconButton(
                    onPressed: onDelete,
                    icon: const Icon(Icons.delete_outline_rounded,
                        color: Colors.redAccent, size: 20),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniChip extends StatelessWidget {
  final String label;
  final Color color;
  const _MiniChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.25), width: 0.8),
      ),
      child: Text(label,
          style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

class _LectureItem {
  final String title;
  final String subject;
  final String category;
  final DateTime uploadedAt;
  final String duration;

  const _LectureItem({
    required this.title,
    required this.subject,
    required this.category,
    required this.uploadedAt,
    required this.duration,
  });
}

class _RecordedBgPainter extends CustomPainter {
  final double progress;
  _RecordedBgPainter({required this.progress});

  void _drawOrb(Canvas canvas, Offset center, double radius, Color color, double opacity) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          color.withOpacity(opacity),
          color.withOpacity(opacity * 0.3),
          color.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final ease = Curves.easeInOut.transform(progress);

    _drawOrb(canvas, Offset(size.width * 0.85, size.height * 0.08 - ease * 10),
        size.width * 0.6, const Color(0xFF3A1500), 0.45);
    _drawOrb(canvas, Offset(-size.width * 0.1 + ease * 8, size.height * 0.5),
        size.width * 0.5, const Color(0xFF1A0A00), 0.40);

    final wavePaint = Paint()
      ..color = Colors.white.withOpacity(0.015)
      ..strokeWidth = 0.7
      ..style = PaintingStyle.stroke;

    const lineCount = 20;
    for (int i = 0; i < lineCount; i++) {
      final yBase = (size.height / (lineCount - 1)) * i;
      final path = Path();
      const steps = 100;
      for (int s = 0; s <= steps; s++) {
        final x = (size.width / steps) * s;
        final y = yBase +
            14.0 * sin((x / size.width) * pi * 2.2 + i * 0.3 + ease * 0.4) +
            6.0 * sin((x / size.width) * pi * 4.4 + i * 0.15);
        s == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
      }
      canvas.drawPath(path, wavePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RecordedBgPainter old) => old.progress != progress;
}