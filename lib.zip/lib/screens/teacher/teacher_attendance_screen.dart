import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:edulearn/screens/auth/api_service.dart';

class TeacherAttendanceScreen extends StatefulWidget {
  const TeacherAttendanceScreen({super.key});
  @override
  State<TeacherAttendanceScreen> createState() => _TeacherAttendanceScreenState();
}

class _TeacherAttendanceScreenState extends State<TeacherAttendanceScreen>
    with TickerProviderStateMixin {

  final TextEditingController _titleCtl = TextEditingController();
  late final AnimationController _bgCtl, _pulseCtl, _qrRevealCtl;
  late final Animation<double> _qrScale, _qrFade;

  bool _sessionActive = false;
  bool _isStarting    = false;
  bool _isClosing     = false;

  String? _sessionId;
  String? _currentQrData;
  int _nonceTtlSeconds = 20;
  int _qrSecondsLeft   = 0;
  int _markedCount     = 0;

  Timer? _qrRefreshTimer, _qrCountdownTimer, _markedCountTimer;
  List<Map<String, dynamic>> _sessions = [];

  static const _accent = Color(0xFF00E5FF);
  static const _bg     = Color(0xFF030810);

  @override
  void initState() {
    super.initState();
    _bgCtl = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat(reverse: true);
    _pulseCtl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _qrRevealCtl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _qrScale = Tween<double>(begin: 0.85, end: 1.0).animate(CurvedAnimation(parent: _qrRevealCtl, curve: Curves.easeOutBack));
    _qrFade  = CurvedAnimation(parent: _qrRevealCtl, curve: Curves.easeIn);
    _loadSessions();
  }

  Future<Position> _getLocation() async {
    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      throw Exception('Location permission denied');
    }
    return Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  Future<void> _startSession() async {
    if (_titleCtl.text.trim().isEmpty) {
      _showSnack('Please enter a session title', Colors.red.shade700); return;
    }
    setState(() => _isStarting = true);
    HapticFeedback.mediumImpact();
    try {
      final pos = await _getLocation();
      final data = await AttendanceApi.startSession(
        title: _titleCtl.text.trim(),
        lat: pos.latitude, lng: pos.longitude,
        radiusM: 100, accuracyM: 50, durationMinutes: 60, nonceTtlSeconds: 20,
      );
      if (data['success'] == true) {
        setState(() {
          _sessionActive    = true;
          _sessionId        = data['sessionId'];
          _currentQrData    = data['qr'];
          _nonceTtlSeconds  = data['nonceTtlSeconds'] ?? 20;
          _qrSecondsLeft    = _nonceTtlSeconds;
          _markedCount      = 0;
        });
        _qrRevealCtl.forward(from: 0);
        _startTimers();
        _loadSessions();
      } else {
        _showSnack(data['message'] ?? 'Failed', Colors.red.shade700);
      }
    } catch (e) {
      _showSnack('Error: $e', Colors.red.shade700);
    } finally {
      setState(() => _isStarting = false);
    }
  }

  Future<void> _refreshNonce() async {
    if (_sessionId == null) return;
    final data = await AttendanceApi.refreshNonce(sessionId: _sessionId!, ttlSeconds: _nonceTtlSeconds);
    if (data['success'] == true && mounted) {
      setState(() { _currentQrData = data['qr']; _qrSecondsLeft = _nonceTtlSeconds; });
    } else if (data['message'] == 'Expired' || data['message'] == 'Not active') {
      _resetSession(); _showSnack('Session expired', Colors.orange);
    }
  }

  Future<void> _closeSession() async {
    if (_sessionId == null) return;
    setState(() => _isClosing = true);
    HapticFeedback.mediumImpact();
    final data = await AttendanceApi.closeSession(_sessionId!);
    if (data['success'] == true) {
      _resetSession();
      _showSnack('Session closed', const Color(0xFF00838F));
      _loadSessions();
    } else {
      _showSnack(data['message'] ?? 'Failed', Colors.red.shade700);
    }
    setState(() => _isClosing = false);
  }

  Future<void> _loadSessions() async {
    final now = DateTime.now();
    final d = '${now.year}-${now.month.toString().padLeft(2,'0')}-${now.day.toString().padLeft(2,'0')}';
    final data = await AttendanceApi.getSessions(date: d);
    if (data['success'] == true && mounted) {
      setState(() => _sessions = List<Map<String,dynamic>>.from(data['sessions'] ?? []));
    }
  }

  Future<void> _refreshMarkedCount() async {
    if (_sessionId == null) return;
    final data = await AttendanceApi.getSessions();
    if (data['success'] == true && mounted) {
      final list = List<Map<String,dynamic>>.from(data['sessions'] ?? []);
      final cur  = list.firstWhere((s) => s['id'] == _sessionId, orElse: () => {});
      if (cur.isNotEmpty) setState(() => _markedCount = cur['markedCount'] ?? 0);
    }
  }

  void _startTimers() {
    _qrRefreshTimer?.cancel();
    _qrCountdownTimer?.cancel();
    _markedCountTimer?.cancel();
    _qrRefreshTimer   = Timer.periodic(Duration(seconds: _nonceTtlSeconds), (_) { if (_sessionActive) _refreshNonce(); });
    _qrCountdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _qrSecondsLeft = _qrSecondsLeft > 0 ? _qrSecondsLeft - 1 : _nonceTtlSeconds);
    });
    _markedCountTimer = Timer.periodic(const Duration(seconds: 10), (_) { if (_sessionActive) _refreshMarkedCount(); });
  }

  void _resetSession() {
    _qrRefreshTimer?.cancel(); _qrCountdownTimer?.cancel(); _markedCountTimer?.cancel();
    setState(() { _sessionActive = false; _sessionId = null; _currentQrData = null; _qrSecondsLeft = 0; _markedCount = 0; });
    _qrRevealCtl.reverse();
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
      backgroundColor: color, behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  void dispose() {
    _titleCtl.dispose(); _bgCtl.dispose(); _pulseCtl.dispose(); _qrRevealCtl.dispose();
    _qrRefreshTimer?.cancel(); _qrCountdownTimer?.cancel(); _markedCountTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        AnimatedBuilder(animation: _bgCtl, builder: (_, __) =>
            CustomPaint(size: MediaQuery.of(context).size, painter: _BgPainter(progress: _bgCtl.value))),
        SafeArea(child: Column(children: [
          _topBar(),
          Expanded(child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            child: Column(children: [
              _titleCard(), const SizedBox(height: 16),
              _qrCard(),   const SizedBox(height: 20),
              _actionButtons(),
              if (_sessions.isNotEmpty) ...[const SizedBox(height: 24), _sessionHistory()],
            ]),
          )),
        ])),
      ]),
    );
  }

  Widget _topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(4, 12, 16, 4),
    child: Row(children: [
      IconButton(onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 20)),
      const SizedBox(width: 2),
      Container(padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: Color.fromRGBO(0, 229, 255, 0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Color.fromRGBO(0, 229, 255, 0.3)),
          ),
          child: const Icon(Icons.qr_code_2_rounded, color: _accent, size: 20)),
      const SizedBox(width: 12),
      const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Attendance QR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white)),
        Text('Generate & share QR for students', style: TextStyle(fontSize: 12, color: Colors.white38)),
      ]),
      const Spacer(),
      if (_sessionActive) AnimatedBuilder(animation: _pulseCtl, builder: (_, __) =>
          GestureDetector(onTap: _refreshMarkedCount, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Color.fromRGBO(76, 175, 80, (0.12 + _pulseCtl.value * 0.05).clamp(0.0, 1.0)),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Color.fromRGBO(76, 175, 80, (0.4 + _pulseCtl.value * 0.2).clamp(0.0, 1.0))),
            ),
            child: Row(children: [
              Container(width: 7, height: 7, decoration: BoxDecoration(
                  color: Colors.greenAccent,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Color.fromRGBO(105, 240, 174, 0.7), blurRadius: 6)])),
              const SizedBox(width: 6),
              Text('$_markedCount Present', style: const TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w700, fontSize: 12)),
            ]),
          ))),
    ]),
  );

  Widget _titleCard() => _GlassCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Session Title',
          style: TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.5),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _titleCtl,
          enabled: !_sessionActive,
          style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
          decoration: InputDecoration(
            hintText: 'e.g. Math Lecture - Period 3',
            hintStyle: const TextStyle(color: Color.fromRGBO(255, 255, 255, 0.25), fontSize: 14),
            filled: true,
            fillColor: const Color.fromRGBO(255, 255, 255, 0.05),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color.fromRGBO(255, 255, 255, 0.08)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color.fromRGBO(255, 255, 255, 0.08)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: _accent, width: 1.5),
            ),
            disabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color.fromRGBO(255, 255, 255, 0.04)),
            ),
            prefixIcon: Icon(
              Icons.edit_rounded,
              color: _sessionActive ? const Color.fromRGBO(255, 255, 255, 0.12) : const Color.fromRGBO(0, 229, 255, 0.6),
              size: 18,
            ),
          ),
        ),
      ],
    ),
  );

  Widget _qrCard() => _GlassCard(
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.qr_code_rounded, color: Colors.white38, size: 16),
            SizedBox(width: 6),
            Text('QR Code', style: TextStyle(color: Colors.white54, fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 16),
        AnimatedBuilder(
          animation: _qrRevealCtl,
          builder: (_, __) => Opacity(
            opacity: _sessionActive
                ? _qrFade.value
                : (1 - _qrFade.value).clamp(0.0, 1.0),
            child: Transform.scale(
              scale: _sessionActive ? _qrScale.value : 1.0,
              child: Container(
                width: double.infinity,
                height: 240,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: _sessionActive
                      ? [BoxShadow(color: Color.fromRGBO(0, 229, 255, 0.25), blurRadius: 30, spreadRadius: 2)]
                      : [],
                ),
                child: _sessionActive && _currentQrData != null
                    ? ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: QrImageView(
                    data: _currentQrData!,
                    version: QrVersions.auto,
                    backgroundColor: Colors.white,
                    padding: const EdgeInsets.all(10),
                    size: double.infinity,
                  ),
                )
                    : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.qr_code_2_rounded, size: 80, color: Colors.grey.shade300),
                      const SizedBox(height: 8),
                      Text(
                        'Start a session to generate QR',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade400, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        AnimatedBuilder(
          animation: _pulseCtl,
          builder: (_, __) => Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _sessionActive ? const Color(0xFF0A2010) : const Color(0xFF0A0E18),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _sessionActive
                    ? Color.fromRGBO(76, 175, 80, (0.3 + _pulseCtl.value * 0.2).clamp(0.0, 1.0))
                    : const Color.fromRGBO(255, 255, 255, 0.07),
              ),
            ),
            child: _sessionActive
                ? Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 8, height: 8,
                      decoration: BoxDecoration(
                        color: Colors.greenAccent,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Color.fromRGBO(105, 240, 174, 0.6), blurRadius: 8)],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text('Active Session',
                        style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w700, fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  _sessionId ?? '',
                  style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _BadgeChip(
                      icon: Icons.timer_rounded,
                      label: 'QR in ${_qrSecondsLeft}s',
                      color: _qrSecondsLeft <= 5 ? Colors.orange : _accent,
                    ),
                    _BadgeChip(
                      icon: Icons.people_rounded,
                      label: '$_markedCount marked',
                      color: Colors.greenAccent,
                    ),
                    const _BadgeChip(
                      icon: Icons.location_on_rounded,
                      label: '100m',
                    ),
                  ],
                ),
              ],
            )
                : const Center(
              child: Text('Not started', style: TextStyle(color: Colors.white38, fontSize: 13)),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _actionButtons() => Column(children: [
    _ActionButton(
        onTap: (!_sessionActive && !_isStarting) ? _startSession : null,
        color: _sessionActive ? const Color(0xFF1B3A1F) : const Color(0xFF1DB954),
        borderColor: _sessionActive ? const Color.fromRGBO(76, 175, 80, 0.2) : Colors.green,
        icon: _isStarting ? Icons.hourglass_top_rounded : Icons.play_arrow_rounded,
        label: _isStarting ? 'Starting...' : 'Start Session',
        textColor: _sessionActive ? Colors.white30 : Colors.white),
    const SizedBox(height: 12),
    _ActionButton(
        onTap: (_sessionActive && !_isClosing) ? _closeSession : null,
        color: _sessionActive ? const Color(0xFFC62828) : const Color(0xFF3A1A1A),
        borderColor: _sessionActive ? const Color.fromRGBO(244, 67, 54, 0.4) : const Color.fromRGBO(244, 67, 54, 0.1),
        icon: _isClosing ? Icons.hourglass_top_rounded : Icons.stop_rounded,
        label: _isClosing ? 'Closing...' : 'Close Session',
        textColor: _sessionActive ? Colors.white : Colors.white24),
    const SizedBox(height: 12),
    _ActionButton(
        onTap: _sessionId != null ? () {
          final url = AttendanceApi.exportUrl(_sessionId!);
          _showSnack('Export URL copied: $url', const Color(0xFF00838F));
        } : null,
        color: _sessionId != null ? const Color(0xFF006064) : const Color(0xFF0A1628),
        borderColor: _sessionId != null ? const Color(0xFF00838F) : Colors.white10,
        icon: Icons.download_rounded,
        label: 'Export CSV',
        textColor: _sessionId != null ? Colors.white : Colors.white24),
  ]);

  Widget _sessionHistory() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      const Text("Today's Sessions", style: TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.w700)),
      const Spacer(),
      GestureDetector(onTap: _loadSessions, child: const Icon(Icons.refresh_rounded, color: Colors.white38, size: 18)),
    ]),
    const SizedBox(height: 12),
    ..._sessions.map((s) {
      final isActive = s['status'] == 'ACTIVE';
      final color = isActive ? Colors.greenAccent : Colors.white38;
      return Container(
        margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color.fromRGBO(10, 22, 40, 0.8),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive ? const Color.fromRGBO(76, 175, 80, 0.3) : const Color.fromRGBO(255, 255, 255, 0.06),
          ),
        ),
        child: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: Color.fromRGBO(
                isActive ? 105 : 255,
                isActive ? 240 : 255,
                isActive ? 174 : 255,
                0.12,
              ),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(isActive ? Icons.radio_button_checked : Icons.check_circle_outline, color: color, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s['title'] ?? 'Session', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
            Text('${s['markedCount'] ?? 0} marked  •  ${s['radius_m'] ?? 100}m range',
                style: const TextStyle(color: Color.fromRGBO(255, 255, 255, 0.35), fontSize: 11)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: Color.fromRGBO(
                isActive ? 105 : 255,
                isActive ? 240 : 255,
                isActive ? 174 : 255,
                0.1,
              ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Color.fromRGBO(
                isActive ? 105 : 255,
                isActive ? 240 : 255,
                isActive ? 174 : 255,
                0.3,
              )),
            ),
            child: Text(isActive ? 'ACTIVE' : 'CLOSED',
                style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900)),
          ),
        ]),
      );
    }),
  ]);
}

class _GlassCard extends StatelessWidget {
  final Widget child;
  const _GlassCard({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity, padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color.fromRGBO(10, 22, 40, 0.85),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color.fromRGBO(255, 255, 255, 0.07)),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 4))],
    ),
    child: child,
  );
}

class _ActionButton extends StatelessWidget {
  final VoidCallback? onTap;
  final Color color, borderColor, textColor;
  final IconData icon;
  final String label;
  const _ActionButton({required this.onTap, required this.color, required this.borderColor,
    required this.icon, required this.label, required this.textColor});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200), width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 1.2),
        boxShadow: onTap != null
            ? [BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 12, offset: const Offset(0, 4))]
            : [],
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: textColor, size: 22), const SizedBox(width: 10),
        Text(label, style: TextStyle(color: textColor, fontSize: 16, fontWeight: FontWeight.w700)),
      ]),
    ),
  );
}

class _BadgeChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _BadgeChip({required this.icon, required this.label, this.color = Colors.white54});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.08),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: color.withValues(alpha: 0.2), width: 0.8),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: color, size: 13), const SizedBox(width: 4),
      Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w500)),
    ]),
  );
}

class _BgPainter extends CustomPainter {
  final double progress;
  _BgPainter({required this.progress});
  @override
  void paint(Canvas canvas, Size size) {
    final e = Curves.easeInOut.transform(progress);
    void orb(Offset c, double r, Color col, double op) => canvas.drawCircle(c, r, Paint()
      ..shader = RadialGradient(colors: [col.withValues(alpha: op), col.withValues(alpha: op * 0.3), col.withValues(alpha: 0)])
          .createShader(Rect.fromCircle(center: c, radius: r)));
    orb(Offset(size.width * 0.85, size.height * 0.08 - e * 10), size.width * 0.6, const Color(0xFF003A45), 0.45);
    orb(Offset(-size.width * 0.1 + e * 8, size.height * 0.5),   size.width * 0.5, const Color(0xFF002030), 0.40);
    final p = Paint()..color = Colors.white.withValues(alpha: 0.015)..strokeWidth = 0.7..style = PaintingStyle.stroke;
    for (int i = 0; i < 20; i++) {
      final y = (size.height / 19) * i;
      final path = Path();
      for (int s = 0; s <= 100; s++) {
        final x = (size.width / 100) * s;
        final yy = y + 14.0 * sin((x / size.width) * pi * 2.2 + i * 0.3 + e * 0.4) + 6.0 * sin((x / size.width) * pi * 4.4 + i * 0.15);
        s == 0 ? path.moveTo(x, yy) : path.lineTo(x, yy);
      }
      canvas.drawPath(path, p);
    }
  }
  @override
  bool shouldRepaint(covariant _BgPainter old) => old.progress != progress;
}