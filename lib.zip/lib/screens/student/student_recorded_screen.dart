import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─── PACKAGES NEEDED (pubspec.yaml) ──────────────────────────────────────────
// chewie: ^1.7.5              ← Video player UI (controls, fullscreen)
// video_player: ^2.8.3        ← Core video playback
// cached_network_image: ^3.3.1 ← Video thumbnails
// http: ^1.6.0                ← API calls
// ─────────────────────────────────────────────────────────────────────────────

// ─── TODO: API ENDPOINTS ─────────────────────────────────────────────────────
// GET $BASE_URL/recorded/subjects          → List of subjects
// GET $BASE_URL/recorded/videos?subject=   → Videos by subject
// GET $BASE_URL/recorded/recent?studentId= → Recently watched
// POST $BASE_URL/recorded/progress         → Save watch progress
//   body: { studentId, videoId, watchedSeconds, totalSeconds }
// ─────────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════════
// MODELS
// ═══════════════════════════════════════════════════════════════════════════════

class RecordedVideo {
  final String id;
  final String title;
  final String subject;
  final String teacher;
  final String duration;       // "45:32"
  final int durationSeconds;
  final int watchedSeconds;
  final String thumbnailColor; // for mock gradient thumbnails
  final String date;
  final String chapter;
  final bool isNew;

  RecordedVideo({
    required this.id,
    required this.title,
    required this.subject,
    required this.teacher,
    required this.duration,
    required this.durationSeconds,
    required this.watchedSeconds,
    required this.thumbnailColor,
    required this.date,
    required this.chapter,
    this.isNew = false,
  });

  double get progress =>
      durationSeconds == 0 ? 0 : watchedSeconds / durationSeconds;
  bool get isWatched => progress >= 0.95;
  bool get isStarted => watchedSeconds > 0 && !isWatched;

  String get remainingTime {
    final rem = durationSeconds - watchedSeconds;
    final m = rem ~/ 60;
    final s = rem % 60;
    return '${m}m ${s}s left';
  }
}

class SubjectGroup {
  final String name;
  final String icon;
  final Color color;
  final List<RecordedVideo> videos;

  SubjectGroup({
    required this.name,
    required this.icon,
    required this.color,
    required this.videos,
  });

  int get watchedCount => videos.where((v) => v.isWatched).length;
  double get completionRate =>
      videos.isEmpty ? 0 : watchedCount / videos.length;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════════════════

final List<SubjectGroup> _mockSubjects = [
  SubjectGroup(
    name: 'Mathematics', icon: '📐', color: const Color(0xFF6C63FF),
    videos: [
      RecordedVideo(id: 'v1', title: 'Quadratic Equations — Part 1',
          subject: 'Mathematics', teacher: 'Himanshu Sir',
          duration: '42:18', durationSeconds: 2538, watchedSeconds: 2538,
          thumbnailColor: '6C63FF', date: '18 Feb', chapter: 'Ch 5', isNew: false),
      RecordedVideo(id: 'v2', title: 'Quadratic Equations — Part 2',
          subject: 'Mathematics', teacher: 'Himanshu Sir',
          duration: '38:45', durationSeconds: 2325, watchedSeconds: 1200,
          thumbnailColor: '7C73FF', date: '19 Feb', chapter: 'Ch 5'),
      RecordedVideo(id: 'v3', title: 'Introduction to Trigonometry',
          subject: 'Mathematics', teacher: 'Himanshu Sir',
          duration: '51:22', durationSeconds: 3082, watchedSeconds: 0,
          thumbnailColor: '9C8FFF', date: '20 Feb', chapter: 'Ch 6', isNew: true),
      RecordedVideo(id: 'v4', title: 'Trigonometric Identities',
          subject: 'Mathematics', teacher: 'Himanshu Sir',
          duration: '44:10', durationSeconds: 2650, watchedSeconds: 0,
          thumbnailColor: '5C53EF', date: '21 Feb', chapter: 'Ch 6', isNew: true),
    ],
  ),
  SubjectGroup(
    name: 'Science', icon: '🔬', color: const Color(0xFF00D4AA),
    videos: [
      RecordedVideo(id: 'v5', title: 'Newton\'s Laws of Motion',
          subject: 'Science', teacher: 'Priya Ma\'am',
          duration: '35:00', durationSeconds: 2100, watchedSeconds: 2100,
          thumbnailColor: '00D4AA', date: '17 Feb', chapter: 'Ch 3'),
      RecordedVideo(id: 'v6', title: 'Friction & Its Applications',
          subject: 'Science', teacher: 'Priya Ma\'am',
          duration: '29:15', durationSeconds: 1755, watchedSeconds: 900,
          thumbnailColor: '00C49A', date: '18 Feb', chapter: 'Ch 3'),
      RecordedVideo(id: 'v7', title: 'Gravitation — Concept Class',
          subject: 'Science', teacher: 'Priya Ma\'am',
          duration: '47:30', durationSeconds: 2850, watchedSeconds: 0,
          thumbnailColor: '00B48A', date: '21 Feb', chapter: 'Ch 4', isNew: true),
    ],
  ),
  SubjectGroup(
    name: 'English', icon: '📖', color: const Color(0xFFFF6584),
    videos: [
      RecordedVideo(id: 'v8', title: 'Essay Writing Techniques',
          subject: 'English', teacher: 'Ananya Ma\'am',
          duration: '28:40', durationSeconds: 1720, watchedSeconds: 1720,
          thumbnailColor: 'FF6584', date: '16 Feb', chapter: 'Writing'),
      RecordedVideo(id: 'v9', title: 'Grammar: Tenses Deep Dive',
          subject: 'English', teacher: 'Ananya Ma\'am',
          duration: '33:55', durationSeconds: 2035, watchedSeconds: 0,
          thumbnailColor: 'EF5574', date: '20 Feb', chapter: 'Grammar', isNew: true),
    ],
  ),
  SubjectGroup(
    name: 'History', icon: '🌍', color: const Color(0xFFFFB347),
    videos: [
      RecordedVideo(id: 'v10', title: 'World War II — Causes & Effects',
          subject: 'History', teacher: 'Rohan Sir',
          duration: '55:10', durationSeconds: 3310, watchedSeconds: 1800,
          thumbnailColor: 'FFB347', date: '15 Feb', chapter: 'Ch 8'),
      RecordedVideo(id: 'v11', title: 'The Cold War Era',
          subject: 'History', teacher: 'Rohan Sir',
          duration: '48:22', durationSeconds: 2902, watchedSeconds: 0,
          thumbnailColor: 'EFA337', date: '19 Feb', chapter: 'Ch 9', isNew: true),
    ],
  ),
];

List<RecordedVideo> get _recentlyWatched => _mockSubjects
    .expand((s) => s.videos)
    .where((v) => v.isStarted || v.isWatched)
    .toList()
  ..sort((a, b) => b.watchedSeconds.compareTo(a.watchedSeconds));

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN SCREEN
// ═══════════════════════════════════════════════════════════════════════════════

class StudentRecordedScreen extends StatefulWidget {
  const StudentRecordedScreen({super.key});

  @override
  State<StudentRecordedScreen> createState() => _StudentRecordedScreenState();
}

class _StudentRecordedScreenState extends State<StudentRecordedScreen>
    with TickerProviderStateMixin {
  late AnimationController _bgCtl;
  late AnimationController _listCtl;
  late Animation<double> _listAnim;

  String _searchQuery = '';
  SubjectGroup? _selectedSubject;
  bool _isSearching = false;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _bgCtl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))
      ..repeat(reverse: true);
    _listCtl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _listAnim = CurvedAnimation(parent: _listCtl, curve: Curves.easeOutCubic);
    _listCtl.forward();
  }

  @override
  void dispose() {
    _bgCtl.dispose();
    _listCtl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  List<RecordedVideo> get _searchResults => _mockSubjects
      .expand((s) => s.videos)
      .where((v) =>
  v.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
      v.subject.toLowerCase().contains(_searchQuery.toLowerCase()) ||
      v.teacher.toLowerCase().contains(_searchQuery.toLowerCase()))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF030810),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _bgCtl,
            builder: (_, __) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _RecordedBgPainter(progress: _bgCtl.value),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                if (_isSearching) _buildSearchBar(),
                Expanded(
                  child: _isSearching && _searchQuery.isNotEmpty
                      ? _buildSearchResults()
                      : _selectedSubject != null
                      ? _buildSubjectVideoList(_selectedSubject!)
                      : _buildHomeView(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Top Bar ─────────────────────────────────────────────────────────────────

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 12, 16, 4),
      child: Row(
        children: [
          IconButton(
            onPressed: () {
              if (_selectedSubject != null) {
                setState(() => _selectedSubject = null);
              } else {
                Navigator.pop(context);
              }
            },
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 20),
          ),
          const SizedBox(width: 2),
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: const Color(0xFFB84A00).withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: const Color(0xFFFF6B2B).withOpacity(0.4)),
            ),
            child: const Icon(Icons.video_library_rounded,
                color: Color(0xFFFF6B2B), size: 20),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _selectedSubject?.name ?? 'Recorded Lectures',
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 0.2),
              ),
              Text(
                _selectedSubject != null
                    ? '${_selectedSubject!.videos.length} lectures'
                    : 'Learn at your own pace',
                style: const TextStyle(fontSize: 12, color: Colors.white38),
              ),
            ],
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) {
                  _searchQuery = '';
                  _searchCtrl.clear();
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Icon(
                _isSearching ? Icons.close : Icons.search,
                color: Colors.white60,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFFF6B2B).withOpacity(0.3)),
        ),
        child: TextField(
          controller: _searchCtrl,
          autofocus: true,
          onChanged: (v) => setState(() => _searchQuery = v),
          style: const TextStyle(color: Colors.white, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Search videos, subjects, teachers...',
            hintStyle:
            TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 14),
            prefixIcon: Icon(Icons.search,
                color: Colors.white.withOpacity(0.3), size: 18),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
    );
  }

  // ── Home View ────────────────────────────────────────────────────────────────

  Widget _buildHomeView() {
    final recent = _recentlyWatched;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
      children: [
        // Overall progress card
        _buildProgressCard(),
        const SizedBox(height: 24),

        // Continue watching
        if (recent.isNotEmpty) ...[
          _sectionHeader('Continue Watching', '${recent.length} in progress'),
          const SizedBox(height: 12),
          SizedBox(
            height: 210,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: recent.length,
              itemBuilder: (context, i) {
                return AnimatedBuilder(
                  animation: _listAnim,
                  builder: (_, child) {
                    final delay = i * 0.1;
                    final v = (((_listAnim.value - delay) / (1 - delay)))
                        .clamp(0.0, 1.0);
                    return Opacity(
                      opacity: v,
                      child: Transform.translate(
                          offset: Offset(20 * (1 - v), 0), child: child),
                    );
                  },
                  child: _ContinueWatchingCard(
                    video: recent[i],
                    onTap: () => _openPlayer(recent[i]),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 24),
        ],

        // Subjects
        _sectionHeader('By Subject', '${_mockSubjects.length} subjects'),
        const SizedBox(height: 12),
        ..._mockSubjects.asMap().entries.map((entry) {
          final i = entry.key;
          final subject = entry.value;
          return AnimatedBuilder(
            animation: _listAnim,
            builder: (_, child) {
              final delay = i * 0.08;
              final v =
              ((_listAnim.value - delay) / (1 - delay)).clamp(0.0, 1.0);
              final curve = Curves.easeOutCubic.transform(v);
              return Opacity(
                opacity: curve,
                child: Transform.translate(
                    offset: Offset(0, 20 * (1 - curve)), child: child),
              );
            },
            child: _SubjectCard(
              subject: subject,
              onTap: () {
                setState(() => _selectedSubject = subject);
                _listCtl.reset();
                _listCtl.forward();
              },
            ),
          );
        }),
      ],
    );
  }

  Widget _buildProgressCard() {
    final totalVideos =
    _mockSubjects.fold(0, (sum, s) => sum + s.videos.length);
    final watchedVideos = _mockSubjects.fold(
        0, (sum, s) => sum + s.videos.where((v) => v.isWatched).length);
    final inProgress = _mockSubjects.fold(
        0, (sum, s) => sum + s.videos.where((v) => v.isStarted).length);
    final completion = totalVideos == 0 ? 0.0 : watchedVideos / totalVideos;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFB84A00).withOpacity(0.2),
            const Color(0xFF6C3483).withOpacity(0.15),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: const Color(0xFFFF6B2B).withOpacity(0.25)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _statBox('$totalVideos', 'Total\nLectures',
                  const Color(0xFFFF6B2B)),
              _vDivider(),
              _statBox('$watchedVideos', 'Completed',
                  const Color(0xFF00D4AA)),
              _vDivider(),
              _statBox('$inProgress', 'In\nProgress',
                  const Color(0xFFFFB347)),
              _vDivider(),
              _statBox(
                  '${(completion * 100).toInt()}%',
                  'Done',
                  const Color(0xFF6C63FF)),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text('Overall completion',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.45),
                      fontSize: 12,
                      fontWeight: FontWeight.w500)),
              const Spacer(),
              Text('${(completion * 100).toInt()}%',
                  style: const TextStyle(
                      color: Color(0xFFFF6B2B),
                      fontWeight: FontWeight.w800,
                      fontSize: 12)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: completion,
              backgroundColor: Colors.white.withOpacity(0.06),
              valueColor:
              const AlwaysStoppedAnimation<Color>(Color(0xFFFF6B2B)),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statBox(String val, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(val,
              style: TextStyle(
                  color: color,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5)),
          const SizedBox(height: 2),
          Text(label,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.35),
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  height: 1.3)),
        ],
      ),
    );
  }

  Widget _vDivider() => Container(
      width: 1, height: 36, color: Colors.white.withOpacity(0.07));

  Widget _sectionHeader(String title, String subtitle) {
    return Row(
      children: [
        Text(title,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w800)),
        const SizedBox(width: 8),
        Container(
          padding:
          const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(subtitle,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }

  // ── Subject Video List ───────────────────────────────────────────────────────

  Widget _buildSubjectVideoList(SubjectGroup subject) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
      itemCount: subject.videos.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) return _buildSubjectHeader(subject);
        final video = subject.videos[i - 1];
        return AnimatedBuilder(
          animation: _listAnim,
          builder: (_, child) {
            final delay = (i - 1) * 0.08;
            final v =
            ((_listAnim.value - delay) / (1 - delay)).clamp(0.0, 1.0);
            final curve = Curves.easeOutCubic.transform(v);
            return Opacity(
              opacity: curve,
              child: Transform.translate(
                  offset: Offset(0, 20 * (1 - curve)), child: child),
            );
          },
          child: _VideoListTile(
            video: video,
            index: i,
            color: subject.color,
            onTap: () => _openPlayer(video),
          ),
        );
      },
    );
  }

  Widget _buildSubjectHeader(SubjectGroup subject) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            subject.color.withOpacity(0.15),
            subject.color.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: subject.color.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          Text(subject.icon, style: const TextStyle(fontSize: 32)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(subject.name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                Text(
                    '${subject.watchedCount}/${subject.videos.length} completed',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.45),
                        fontSize: 13)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${(subject.completionRate * 100).toInt()}%',
                style: TextStyle(
                    color: subject.color,
                    fontSize: 24,
                    fontWeight: FontWeight.w900),
              ),
              Text('done',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.3),
                      fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  // ── Search Results ───────────────────────────────────────────────────────────

  Widget _buildSearchResults() {
    final results = _searchResults;
    if (results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🔍', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text('No videos found for "$_searchQuery"',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.4), fontSize: 14)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
      itemCount: results.length,
      itemBuilder: (context, i) {
        final subjectColor = _mockSubjects
            .firstWhere((s) => s.name == results[i].subject,
            orElse: () => _mockSubjects.first)
            .color;
        return _VideoListTile(
          video: results[i],
          index: i + 1,
          color: subjectColor,
          onTap: () => _openPlayer(results[i]),
        );
      },
    );
  }

  // ── Open Player ──────────────────────────────────────────────────────────────

  void _openPlayer(RecordedVideo video) {
    HapticFeedback.lightImpact();
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: VideoPlayerScreen(video: video),
        ),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONTINUE WATCHING CARD (horizontal scroll)
// ═══════════════════════════════════════════════════════════════════════════════

class _ContinueWatchingCard extends StatelessWidget {
  final RecordedVideo video;
  final VoidCallback onTap;

  const _ContinueWatchingCard(
      {required this.video, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color =
    Color(int.parse('FF${video.thumbnailColor}', radix: 16));

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 200,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0A1628),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            Stack(
              children: [
                Container(
                  height: 110,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        color.withOpacity(0.8),
                        color.withOpacity(0.4),
                      ],
                    ),
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(16)),
                  ),
                  child: Center(
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4),
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Colors.white.withOpacity(0.6),
                            width: 2),
                      ),
                      child: const Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 24),
                    ),
                  ),
                ),
                // Duration badge
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(video.duration,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
                // NEW badge
                if (video.isNew)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF6B2B),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text('NEW',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w900)),
                    ),
                  ),
              ],
            ),
            // Info
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(video.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          height: 1.3)),
                  const SizedBox(height: 5),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: video.progress,
                      backgroundColor: Colors.white.withOpacity(0.08),
                      valueColor: AlwaysStoppedAnimation<Color>(color),
                      minHeight: 3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    video.isWatched ? 'Completed ✓' : video.remainingTime,
                    style: TextStyle(
                        color: video.isWatched
                            ? const Color(0xFF00D4AA)
                            : color,
                        fontSize: 10,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SUBJECT CARD
// ═══════════════════════════════════════════════════════════════════════════════

class _SubjectCard extends StatelessWidget {
  final SubjectGroup subject;
  final VoidCallback onTap;

  const _SubjectCard({required this.subject, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF0A1628),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: subject.color.withOpacity(0.2)),
          boxShadow: [
            BoxShadow(
                color: subject.color.withOpacity(0.06),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: subject.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                  child: Text(subject.icon,
                      style: const TextStyle(fontSize: 26))),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(subject.name,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(width: 6),
                      // New badge
                      if (subject.videos.any((v) => v.isNew))
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF6B2B).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '${subject.videos.where((v) => v.isNew).length} new',
                            style: const TextStyle(
                                color: Color(0xFFFF6B2B),
                                fontSize: 9,
                                fontWeight: FontWeight.w900),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                      '${subject.videos.length} lectures  •  ${subject.watchedCount} done',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 12)),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: subject.completionRate,
                      backgroundColor: Colors.white.withOpacity(0.06),
                      valueColor:
                      AlwaysStoppedAnimation<Color>(subject.color),
                      minHeight: 4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                    '${(subject.completionRate * 100).toInt()}%',
                    style: TextStyle(
                        color: subject.color,
                        fontSize: 18,
                        fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Icon(Icons.chevron_right,
                    color: Colors.white.withOpacity(0.25), size: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// VIDEO LIST TILE
// ═══════════════════════════════════════════════════════════════════════════════

class _VideoListTile extends StatelessWidget {
  final RecordedVideo video;
  final int index;
  final Color color;
  final VoidCallback onTap;

  const _VideoListTile({
    required this.video,
    required this.index,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: video.isStarted
              ? color.withOpacity(0.06)
              : const Color(0xFF0A1628),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: video.isStarted
                ? color.withOpacity(0.25)
                : Colors.white.withOpacity(0.06),
          ),
        ),
        child: Row(
          children: [
            // Thumbnail / number
            Stack(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        color.withOpacity(0.7),
                        color.withOpacity(0.35),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: video.isWatched
                        ? const Icon(Icons.check_circle_rounded,
                        color: Colors.white, size: 28)
                        : Icon(Icons.play_circle_outline_rounded,
                        color: Colors.white.withOpacity(0.9),
                        size: 28),
                  ),
                ),
                if (video.isNew)
                  Positioned(
                    top: 4,
                    right: 4,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFF6B2B),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(video.chapter,
                            style: TextStyle(
                                color: color,
                                fontSize: 9,
                                fontWeight: FontWeight.w800)),
                      ),
                      if (video.isNew) ...[
                        const SizedBox(width: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF6B2B).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text('NEW',
                              style: TextStyle(
                                  color: Color(0xFFFF6B2B),
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(video.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          height: 1.3)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.access_time,
                          color: Colors.white.withOpacity(0.3), size: 11),
                      const SizedBox(width: 3),
                      Text(video.duration,
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.35),
                              fontSize: 11)),
                      const SizedBox(width: 8),
                      if (video.isStarted) ...[
                        Icon(Icons.circle, color: color, size: 4),
                        const SizedBox(width: 4),
                        Text(video.remainingTime,
                            style: TextStyle(
                                color: color,
                                fontSize: 11,
                                fontWeight: FontWeight.w600)),
                      ] else if (video.isWatched) ...[
                        const Icon(Icons.circle,
                            color: Color(0xFF00D4AA), size: 4),
                        const SizedBox(width: 4),
                        const Text('Completed',
                            style: TextStyle(
                                color: Color(0xFF00D4AA),
                                fontSize: 11,
                                fontWeight: FontWeight.w600)),
                      ],
                    ],
                  ),
                  // Progress bar (if started)
                  if (video.isStarted) ...[
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: LinearProgressIndicator(
                        value: video.progress,
                        backgroundColor: Colors.white.withOpacity(0.06),
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                        minHeight: 3,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right,
                color: Colors.white.withOpacity(0.2), size: 18),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// VIDEO PLAYER SCREEN
// ═══════════════════════════════════════════════════════════════════════════════

class VideoPlayerScreen extends StatefulWidget {
  final RecordedVideo video;
  const VideoPlayerScreen({super.key, required this.video});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen>
    with TickerProviderStateMixin {
  // TODO: Initialize real video player
  // late VideoPlayerController _videoCtrl;
  // late ChewieController _chewieCtrl;

  bool _isPlaying = false;
  bool _showControls = true;
  double _currentSeconds = 0;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _bgCtl;

  @override
  void initState() {
    super.initState();
    _currentSeconds = widget.video.watchedSeconds.toDouble();

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeInOut);
    _fadeCtrl.forward();

    _bgCtl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat(reverse: true);

    // TODO: Real video init
    // _videoCtrl = VideoPlayerController.network('YOUR_VIDEO_URL')
    //   ..initialize().then((_) {
    //     _videoCtrl.seekTo(Duration(seconds: widget.video.watchedSeconds));
    //     setState(() {});
    //   });
    // _chewieCtrl = ChewieController(videoPlayerController: _videoCtrl, ...);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _bgCtl.dispose();
    // _videoCtrl.dispose();
    // _chewieCtrl.dispose();
    super.dispose();
  }

  String _formatTime(double seconds) {
    final m = seconds ~/ 60;
    final s = (seconds % 60).toInt();
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(
        int.parse('FF${widget.video.thumbnailColor}', radix: 16));

    return Scaffold(
      backgroundColor: const Color(0xFF030810),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _bgCtl,
            builder: (_, __) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _RecordedBgPainter(progress: _bgCtl.value),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                children: [
                  // Back bar
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 8, 16, 0),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.arrow_back_ios_new_rounded,
                              color: Colors.white70, size: 20),
                        ),
                        Expanded(
                          child: Text(widget.video.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14)),
                        ),
                      ],
                    ),
                  ),

                  // ── VIDEO AREA ───────────────────────────────────────────
                  GestureDetector(
                    onTap: () {
                      setState(() => _showControls = !_showControls);
                    },
                    child: Container(
                      width: double.infinity,
                      height: 220,
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            color.withOpacity(0.5),
                            Colors.black,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        border:
                        Border.all(color: color.withOpacity(0.3)),
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // TODO: Replace with Chewie player
                          // Chewie(controller: _chewieCtrl),

                          // Mock player UI
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.play_circle_fill_rounded,
                                  color: Colors.white.withOpacity(0.15),
                                  size: 80),
                              const SizedBox(height: 8),
                              Text('Video Player',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.2),
                                      fontSize: 13)),
                              Text('(chewie package)',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.1),
                                      fontSize: 11)),
                            ],
                          ),

                          // Controls overlay
                          if (_showControls)
                            AnimatedOpacity(
                              opacity: _showControls ? 1.0 : 0.0,
                              duration: const Duration(milliseconds: 200),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: [
                                    // -10s
                                    IconButton(
                                      onPressed: () => setState(() =>
                                      _currentSeconds =
                                          (_currentSeconds - 10)
                                              .clamp(0,
                                              widget.video.durationSeconds.toDouble())),
                                      icon: const Icon(
                                          Icons.replay_10_rounded,
                                          color: Colors.white,
                                          size: 30),
                                    ),
                                    const SizedBox(width: 20),
                                    // Play/Pause
                                    GestureDetector(
                                      onTap: () => setState(
                                              () => _isPlaying = !_isPlaying),
                                      child: Container(
                                        width: 60,
                                        height: 60,
                                        decoration: BoxDecoration(
                                          color: color.withOpacity(0.9),
                                          shape: BoxShape.circle,
                                          boxShadow: [
                                            BoxShadow(
                                                color: color.withOpacity(0.4),
                                                blurRadius: 16)
                                          ],
                                        ),
                                        child: Icon(
                                          _isPlaying
                                              ? Icons.pause_rounded
                                              : Icons.play_arrow_rounded,
                                          color: Colors.white,
                                          size: 32,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 20),
                                    // +10s
                                    IconButton(
                                      onPressed: () => setState(() =>
                                      _currentSeconds =
                                          (_currentSeconds + 10).clamp(
                                              0,
                                              widget.video.durationSeconds.toDouble())),
                                      icon: const Icon(
                                          Icons.forward_10_rounded,
                                          color: Colors.white,
                                          size: 30),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                          // Fullscreen & time
                          Positioned(
                            bottom: 12,
                            left: 14,
                            right: 14,
                            child: Row(
                              children: [
                                Text(
                                  '${_formatTime(_currentSeconds)} / ${widget.video.duration}',
                                  style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600),
                                ),
                                const Spacer(),
                                GestureDetector(
                                  onTap: () {
                                    SystemChrome.setPreferredOrientations([
                                      DeviceOrientation.landscapeLeft,
                                      DeviceOrientation.landscapeRight,
                                    ]);
                                  },
                                  child: const Icon(Icons.fullscreen_rounded,
                                      color: Colors.white60, size: 20),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ── SEEK BAR ─────────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Column(
                      children: [
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            trackHeight: 3,
                            thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 6),
                            overlayShape: const RoundSliderOverlayShape(
                                overlayRadius: 14),
                            activeTrackColor: color,
                            inactiveTrackColor:
                            Colors.white.withOpacity(0.1),
                            thumbColor: color,
                            overlayColor: color.withOpacity(0.2),
                          ),
                          child: Slider(
                            value: _currentSeconds,
                            min: 0,
                            max: widget.video.durationSeconds.toDouble(),
                            onChanged: (v) =>
                                setState(() => _currentSeconds = v),
                            onChangeEnd: (v) {
                              // TODO: _videoCtrl.seekTo(Duration(seconds: v.toInt()));
                              // TODO: POST progress to API
                            },
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ── VIDEO INFO ───────────────────────────────────────────
                  Expanded(
                    child: SingleChildScrollView(
                      padding:
                      const EdgeInsets.fromLTRB(20, 8, 20, 30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title + chapter
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(widget.video.chapter,
                                    style: TextStyle(
                                        color: color,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800)),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(widget.video.subject,
                                    style: TextStyle(
                                        color:
                                        Colors.white.withOpacity(0.5),
                                        fontSize: 11)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(widget.video.title,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.3,
                                  height: 1.3)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.person_outline,
                                  color: Colors.white.withOpacity(0.35),
                                  size: 14),
                              const SizedBox(width: 5),
                              Text(widget.video.teacher,
                                  style: TextStyle(
                                      color:
                                      Colors.white.withOpacity(0.45),
                                      fontSize: 13)),
                              const SizedBox(width: 14),
                              Icon(Icons.calendar_today_outlined,
                                  color: Colors.white.withOpacity(0.35),
                                  size: 14),
                              const SizedBox(width: 5),
                              Text(widget.video.date,
                                  style: TextStyle(
                                      color:
                                      Colors.white.withOpacity(0.45),
                                      fontSize: 13)),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Divider(
                              color: Colors.white.withOpacity(0.06)),
                          const SizedBox(height: 16),

                          // Speed selector
                          Text('Playback Speed',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.4),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1)),
                          const SizedBox(height: 10),
                          _SpeedSelector(color: color),
                          const SizedBox(height: 20),

                          // Notes section
                          Text('My Notes',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.4),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1)),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.04),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.07)),
                            ),
                            child: TextField(
                              maxLines: 3,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 13),
                              decoration: InputDecoration(
                                hintText:
                                'Take notes while watching...',
                                hintStyle: TextStyle(
                                    color: Colors.white.withOpacity(0.2),
                                    fontSize: 13),
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Speed Selector ────────────────────────────────────────────────────────────

class _SpeedSelector extends StatefulWidget {
  final Color color;
  const _SpeedSelector({required this.color});

  @override
  State<_SpeedSelector> createState() => _SpeedSelectorState();
}

class _SpeedSelectorState extends State<_SpeedSelector> {
  double _speed = 1.0;
  final List<double> _speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: _speeds.map((s) {
        final selected = _speed == s;
        return Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() => _speed = s);
              // TODO: _chewieCtrl.videoPlayerController.setPlaybackSpeed(s);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: selected
                    ? widget.color.withOpacity(0.2)
                    : Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: selected
                      ? widget.color.withOpacity(0.5)
                      : Colors.white.withOpacity(0.06),
                ),
              ),
              child: Text(
                '${s}x',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: selected ? widget.color : Colors.white38,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// BACKGROUND PAINTER
// ═══════════════════════════════════════════════════════════════════════════════

class _RecordedBgPainter extends CustomPainter {
  final double progress;
  _RecordedBgPainter({required this.progress});

  void _orb(Canvas c, Offset center, double r, Color color, double opacity) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          color.withOpacity(opacity),
          color.withOpacity(opacity * 0.3),
          color.withOpacity(0),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: r));
    c.drawCircle(center, r, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final ease = Curves.easeInOut.transform(progress);
    _orb(canvas, Offset(size.width * 0.85, size.height * 0.1 - ease * 10),
        size.width * 0.55, const Color(0xFF3A1500), 0.5);
    _orb(canvas, Offset(-size.width * 0.1 + ease * 8, size.height * 0.5),
        size.width * 0.5, const Color(0xFF1A0030), 0.4);
    _orb(canvas, Offset(size.width * 0.5, size.height * 0.9),
        size.width * 0.4, const Color(0xFF001830), 0.3);

    final p = Paint()
      ..color = Colors.white.withOpacity(0.015)
      ..strokeWidth = 0.6
      ..style = PaintingStyle.stroke;

    for (int i = 0; i < 10; i++) {
      final x = (size.width / 9) * i;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (int i = 0; i < 18; i++) {
      final y = (size.height / 17) * i;
      final wave = 3.0 * sin(i * 0.5 + ease * 2);
      canvas.drawLine(Offset(0, y + wave), Offset(size.width, y + wave), p);
    }
  }

  @override
  bool shouldRepaint(covariant _RecordedBgPainter old) =>
      old.progress != progress;
}